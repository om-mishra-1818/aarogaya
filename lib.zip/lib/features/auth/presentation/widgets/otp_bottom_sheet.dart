import 'dart:async';
import 'package:aarogyaone/core/utils/preference_utils.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'package:pinput/pinput.dart';
import '../../../../core/theme/app_colors.dart';
import '../../logic/login_cubit.dart';
import '../../logic/login_state.dart';

class OtpBottomSheet extends StatefulWidget {
  final String phoneNumber;
  final String transactionId;

  const OtpBottomSheet({
    super.key,
    required this.phoneNumber,
    required this.transactionId,
  });

  @override
  State<OtpBottomSheet> createState() => _OtpBottomSheetState();
}

class _OtpBottomSheetState extends State<OtpBottomSheet> {
  final TextEditingController _pinController = TextEditingController();
  
  Timer? _timer;
  int _start = 30;
  bool _canResend = false;
  late String _currentTransactionId;

  @override
  void initState() {
    super.initState();
    _currentTransactionId = widget.transactionId;
    startTimer();
  }

  @override
  void dispose() {
    _timer?.cancel();
    _pinController.dispose();
    super.dispose();
  }

  void startTimer() {
    setState(() {
      _canResend = false;
      _start = 30;
    });

    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_start == 0) {
        setState(() {
          _canResend = true;
          timer.cancel();
        });
      } else {
        setState(() {
          _start--;
        });
      }
    });
  }

  void _onResendPressed() {
    if (!_canResend) return;
    context.read<LoginCubit>().resendOtp(widget.phoneNumber);
    startTimer();
  }

  void _verify(BuildContext context) {
    if (_pinController.text.length != 6) return;
    
    // 1. Close Keyboard IMMEDIATELY when button is pressed
    FocusScope.of(context).unfocus();
    
    context.read<LoginCubit>().verifyOtp(
      widget.phoneNumber, 
      _currentTransactionId,
      _pinController.text
    );
  }

  @override
  Widget build(BuildContext context) {
    final bottomPadding = MediaQuery.of(context).viewInsets.bottom;

    return BlocConsumer<LoginCubit, LoginState>(
      listener: (context, state) async { 
        if (state is OtpError) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(state.message), backgroundColor: AppColors.errorColor),
          );
        } else if (state is OtpResent) {
          _currentTransactionId = state.newTransactionId;
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("OTP Resent Successfully!"), backgroundColor: Colors.green),
          );
        } else if (state is OtpVerified) {

          // 2. Save Data
          await PreferenceUtils().saveLoginDetails("dummy_token");

          // 3. Wait for Keyboard animation (Safety Buffer)
          if (!context.mounted) return;
          await Future.delayed(const Duration(milliseconds: 500));
          
          if (!context.mounted) return;

          // 4. NAVIGATE DIRECTLY (Do not pop)
          // GoRouter will replace the /login page (and this sheet) with /home
          context.go('/home'); 
        }
      },
      builder: (context, state) {
        final isLoading = state is OtpLoading;

        return Container(
          padding: EdgeInsets.only(
            left: 24, right: 24, top: 24,
            bottom: bottomPadding + 24,
          ),
          decoration: const BoxDecoration(
            color: AppColors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
          ),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const SizedBox(width: 40), 
                    const Text("Enter 6 Digit OTP", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    IconButton(
                      icon: const Icon(Icons.close, color: AppColors.grey),
                      onPressed: () => Navigator.pop(context),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                
                Text(
                  "Enter OTP received on mobile number\n(******${widget.phoneNumber.length > 4 ? widget.phoneNumber.substring(widget.phoneNumber.length - 4) : widget.phoneNumber})",
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: AppColors.grey),
                ),
                const SizedBox(height: 30),
                
                Pinput(
                  length: 6,
                  controller: _pinController,
                  autofillHints: const [AutofillHints.oneTimeCode],
                  defaultPinTheme: PinTheme(
                    width: 50, height: 50,
                    textStyle: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    decoration: BoxDecoration(
                      border: Border.all(color: AppColors.lightGreyBlack),
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  focusedPinTheme: PinTheme(
                    width: 50, height: 50,
                    textStyle: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    decoration: BoxDecoration(
                      border: Border.all(color: AppColors.secondaryColor1), 
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  onCompleted: (_) => _verify(context),
                ),
                const SizedBox(height: 20),

                RichText(
                  text: TextSpan(
                    text: _canResend ? "Didn't receive code? " : "Resend code in ",
                    style: const TextStyle(color: AppColors.grey, fontSize: 14),
                    children: [
                      if (!_canResend)
                        TextSpan(
                          text: "${_start}s",
                          style: TextStyle(color: AppColors.secondaryColor1, fontWeight: FontWeight.bold),
                        ),
                      if (_canResend)
                        TextSpan(
                          text: "Resend",
                          style: TextStyle(
                            color: AppColors.secondaryColor1, 
                            fontWeight: FontWeight.bold,
                            decoration: TextDecoration.underline,
                          ),
                          recognizer: TapGestureRecognizer()..onTap = _onResendPressed,
                        ),
                    ],
                  ),
                ),

                const SizedBox(height: 30),
                
                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: ElevatedButton(
                    onPressed: isLoading ? null : () => _verify(context),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.secondaryColor2, 
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                    ),
                    child: isLoading
                        ? const CircularProgressIndicator(color: Colors.white)
                        : const Text("Verify OTP", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
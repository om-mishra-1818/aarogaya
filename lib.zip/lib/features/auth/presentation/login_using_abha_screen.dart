import 'package:aarogyaone/core/utils/app_assets.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../core/theme/app_colors.dart';

class LoginUsingAbhaScreen extends StatefulWidget {
  const LoginUsingAbhaScreen({super.key});

  @override
  State<LoginUsingAbhaScreen> createState() => _LoginUsingAbhaScreenState();
}

class _LoginUsingAbhaScreenState extends State<LoginUsingAbhaScreen> {
  // 0 = ABHA Address, 1 = Mobile Number, 2 = ABHA Number
  int _selectedTab = 0; 
  bool _isButtonEnabled = false; // Controls Button Color & Clickability

  
  final TextEditingController _abhaAddressController = TextEditingController();
  final TextEditingController _mobileController = TextEditingController();
  
  // ABHA Number Controllers
  final TextEditingController _abhaNum1 = TextEditingController();
  final TextEditingController _abhaNum2 = TextEditingController();
  final TextEditingController _abhaNum3 = TextEditingController();
  final TextEditingController _abhaNum4 = TextEditingController();

  // Radio Value (1 = Mobile OTP, 2 = Aadhaar OTP)
  int _otpMethod = 1; 

  void _validateInput() {
    bool isValid = false;

    if (_selectedTab == 0) {
      // ABHA Address: Must be at least 4 characters
      isValid = _abhaAddressController.text.trim().length >= 4;
    } else if (_selectedTab == 1) {
      // Mobile Number: Must be exactly 10 digits
      isValid = _mobileController.text.trim().length == 10;
    } else if (_selectedTab == 2) {
      // ABHA Number: All boxes must be filled (2 + 4 + 4 + 4 = 14 digits)
      isValid = _abhaNum1.text.length == 2 &&
                _abhaNum2.text.length == 4 &&
                _abhaNum3.text.length == 4 &&
                _abhaNum4.text.length == 4;
    }

    if (isValid != _isButtonEnabled) {
      setState(() {
        _isButtonEnabled = isValid;
      });
    }
  }

  void _onTabSelected(int index) {
    setState(() {
      _selectedTab = index;
    });
    _validateInput(); 
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.white,
      appBar: AppBar(
        backgroundColor: AppColors.white,
        elevation: 0,
        leading: IconButton(
          icon:  Icon(Icons.arrow_back, color: AppColors.primaryColor),
          onPressed: () => context.pop(),
        ),
        title: Text(
          _getHeaderTitle(),
          style: const TextStyle(color: AppColors.black, fontSize: 16, fontWeight: FontWeight.bold),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: Center(
              child: Text(
                "आ", 
                style: TextStyle(fontSize: 24, color: AppColors.secondaryColor1, fontWeight: FontWeight.bold),
              ),
            ),
          )
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "Select one option to proceed with",
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
            ),
            const SizedBox(height: 16),

            
            Container(
              height: 50,
              decoration: BoxDecoration(
                color: Colors.grey.shade200,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                children: [
                  _buildTabItem(0, "ABHA\nAddress"),
                  _buildTabItem(1, "Mobile\nNumber"),
                  _buildTabItem(2, "ABHA\nNumber"),
                ],
              ),
            ),
            const SizedBox(height: 24),

            
            if (_selectedTab == 0) _buildAbhaAddressForm(),
            if (_selectedTab == 1) _buildMobileNumberForm(),
            if (_selectedTab == 2) _buildAbhaNumberForm(),

            const SizedBox(height: 30),

            
            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton(
                //  Only enable onPressed if _isButtonEnabled is true
                onPressed: _isButtonEnabled ? () {
                  // Proceed Logic
                  debugPrint("Success! Proceeding with Tab $_selectedTab");
                } : null, // null disables the button click
                
                style: ElevatedButton.styleFrom(
                  //  Blue if enabled, Grey if disabled
                  backgroundColor: _isButtonEnabled ? AppColors.secondaryColor2 : Colors.grey.shade300,
                  
                  disabledBackgroundColor: Colors.grey.shade300,
                  disabledForegroundColor: Colors.grey,
                  
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                  elevation: 0,
                ),
                child: Text(
                  _selectedTab == 0 ? "Request OTP Options" : "Continue",
                  style: TextStyle(
                    color: _isButtonEnabled ? Colors.white : Colors.grey, 
                    fontSize: 16, 
                    fontWeight: FontWeight.bold
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _getHeaderTitle() {
    switch (_selectedTab) {
      case 0: return "Proceed with ABHA Address";
      case 1: return "Proceed with Mobile Number";
      case 2: return "Proceed with ABHA Number";
      default: return "";
    }
  }

  Widget _buildTabItem(int index, String label) {
    final isSelected = _selectedTab == index;
    return Expanded(
      child: GestureDetector(
        onTap: () => _onTabSelected(index),
        child: Container(
          decoration: BoxDecoration(
            color: isSelected ? AppColors.primaryColor : Colors.transparent,
            borderRadius: BorderRadius.circular(8),
          ),
          alignment: Alignment.center,
          child: Text(
            label,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 12,
              fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
              color: isSelected ? Colors.white : AppColors.grey,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildAbhaAddressForm() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text("Enter your ABHA Address", style: TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        TextField(
          controller: _abhaAddressController,
          onChanged: (v) => _validateInput(), 
          decoration: InputDecoration(
            hintText: "Enter your ABHA Address",
            suffixText: "@sbx",
            suffixStyle: TextStyle(color: AppColors.primaryColor, fontWeight: FontWeight.bold),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          ),
        ),
      ],
    );
  }

  Widget _buildMobileNumberForm() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text("Mobile Number", style: TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          decoration: BoxDecoration(
            border: Border.all(color: Colors.grey),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Row(
            children: [
               Image.asset(AppAssets.flag,width: 24,height: 20,), 
              const SizedBox(width: 8),
              const Text("+91", style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(width: 12),
              Container(width: 1, height: 24, color: Colors.grey),
              const SizedBox(width: 12),
              Expanded(
                child: TextField(
                  controller: _mobileController,
                  keyboardType: TextInputType.phone,
                  maxLength: 10,
                  onChanged: (v) => _validateInput(), 
                  decoration: const InputDecoration(
                    hintText: "Enter mobile number",
                    border: InputBorder.none,
                    counterText: "",
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildAbhaNumberForm() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text("ABHA Number", style: TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            _buildSmallInput(_abhaNum1, 2),
            _buildSmallInput(_abhaNum2, 4),
            _buildSmallInput(_abhaNum3, 4),
            _buildSmallInput(_abhaNum4, 4),
          ],
        ),
        const SizedBox(height: 20),
        _buildRadioOption(1, "ABHA Link Mobile Number (You will receive OTP on mobile number linked with your ABHA)"),
        const SizedBox(height: 12),
        _buildRadioOption(2, "Aadhaar Link Mobile Number (You will receive OTP on mobile number linked with your Aadhaar)"),
      ],
    );
  }

  Widget _buildSmallInput(TextEditingController controller, int length) {
    return SizedBox(
      width: length == 2 ? 60 : 75,
      child: TextField(
        controller: controller,
        textAlign: TextAlign.center,
        keyboardType: TextInputType.number,
        maxLength: length,
        onChanged: (value) {
          _validateInput(); //  Trigger Check
          // Auto-Focus Next Field
          if (value.length == length) FocusScope.of(context).nextFocus();
        },
        decoration: InputDecoration(
          hintText: length == 2 ? "XX" : "XXXX",
          counterText: "",
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
          contentPadding: const EdgeInsets.symmetric(vertical: 14),
        ),
      ),
    );
  }

  Widget _buildRadioOption(int value, String text) {
    final bool isSelected = _otpMethod == value;
    return InkWell(
      onTap: () {
        setState(() {
          _otpMethod = value;
        });
      },
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(
            isSelected ? Icons.radio_button_checked : Icons.radio_button_off,
            color: isSelected ? AppColors.primaryColor : Colors.grey,
            size: 24,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(text, style: const TextStyle(fontSize: 13, height: 1.4)),
          ),
        ],
      ),
    );
  }
}
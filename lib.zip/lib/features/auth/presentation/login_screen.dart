import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/utils/app_assets.dart';
import '../data/auth_repository.dart';
import '../logic/login_cubit.dart';
import '../logic/login_state.dart';
import 'widgets/otp_bottom_sheet.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => LoginCubit(AuthRepository()),
      child: const _LoginView(),
    );
  }
}

class _LoginView extends StatefulWidget {
  const _LoginView();
  @override
  State<_LoginView> createState() => _LoginViewState();
}

class _LoginViewState extends State<_LoginView> {
  final TextEditingController _phoneController = TextEditingController();
  bool _isButtonEnabled = false;
  bool _whatsappUpdates = true;
  bool _termsAccepted = false;
  bool _linkAbhaAccepted = false;

  void _onLoginPressed(BuildContext context) {
    if (!_termsAccepted || !_whatsappUpdates || !_linkAbhaAccepted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please accept all Terms & Conditions'), backgroundColor: AppColors.errorColor),
      );
      return;
    }
    context.read<LoginCubit>().login(phoneNumber: _phoneController.text.trim(), termsAccepted: _termsAccepted);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.white,
      appBar: AppBar(
        backgroundColor: AppColors.white,
        elevation: 0,
        leading: Icon(Icons.translate, color: AppColors.secondaryColor1), 
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: IconButton(icon: Icon(Icons.keyboard_arrow_down, color: AppColors.secondaryColor1), onPressed: () {}),
          )
        ],
      ),
      body: BlocConsumer<LoginCubit, LoginState>(
        listener: (context, state) {
          if (state is LoginError) {
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(state.message), backgroundColor: AppColors.errorColor));
          } else if (state is LoginSuccess) {
            final loginCubit = context.read<LoginCubit>();
            showModalBottomSheet(
              context: context,
              isScrollControlled: true,
              backgroundColor: Colors.transparent,
              builder: (_) => BlocProvider.value(
                value: loginCubit,
                child: OtpBottomSheet(phoneNumber: state.phoneNumber, transactionId: state.transactionId),
              ),
            );
          }
        },
        builder: (context, state) {
          final isLoading = state is LoginLoading;
          return SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Column(
                children: [
                  const SizedBox(height: 10),
                  Image.asset(AppAssets.logo, height: 60),
                  const SizedBox(height: 30),
                  const Text("Let's Get Started!!", style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  const Text('Login to enjoy the features we have Provided, and stay healthy!!', textAlign: TextAlign.center, style: TextStyle(color: AppColors.grey)),
                  const SizedBox(height: 30),

                  Container(
                    decoration: BoxDecoration(border: Border.all(color: AppColors.grey), borderRadius: BorderRadius.circular(8)),
                    child: Row(
                      children: [
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 12),
                          child: Row(children: [
                             Image.asset(AppAssets.flag, width: 24, height: 20, errorBuilder: (c,o,s) => const Icon(Icons.flag)),
                             const SizedBox(width: 8),
                             const Text('+91', style: TextStyle(fontWeight: FontWeight.bold)),
                          ]),
                        ),
                        Container(width: 1, height: 30, color: AppColors.grey),
                        Expanded(
                          child: TextField(
                            controller: _phoneController,
                            keyboardType: TextInputType.phone,
                            maxLength: 10,
                            onChanged: (v) => setState(() => _isButtonEnabled = v.length == 10),
                            decoration: const InputDecoration(hintText: "Enter the Number", border: InputBorder.none, counterText: "", contentPadding: EdgeInsets.symmetric(horizontal: 16)),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),

                  SizedBox(
                    width: double.infinity, height: 50,
                    child: ElevatedButton(
                      onPressed: (_isButtonEnabled && !isLoading) ? () => _onLoginPressed(context) : null,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.secondaryColor2,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      ),
                      child: isLoading
                          ? const CircularProgressIndicator(color: Colors.white)
                          : const Text("Login or Register", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white)),
                    ),
                  ),
                  const SizedBox(height: 20),
                  const Row(children: [Expanded(child: Divider()), Padding(padding: EdgeInsets.all(8), child: Text('Or', style: TextStyle(color: AppColors.grey))), Expanded(child: Divider())]),
                  const SizedBox(height: 20),
                  
                  SizedBox(
                    width: double.infinity, height: 50, 
                    child: ElevatedButton(
                      onPressed: () {
                         context.push('/login-abha');
                      }, 
                      style: ElevatedButton.styleFrom(backgroundColor: AppColors.secondaryColor2, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8))), 
                      child: const Text('Login using ABHA', style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold))
                    )
                  ),
                  const SizedBox(height: 30),
                  const Row(children: [Expanded(child: Divider()), Padding(padding: EdgeInsets.all(8), child: Text('Quick Links')), Expanded(child: Divider())]),
                  const SizedBox(height: 20),

                  Row(
                    children: [
                      Expanded(child: SizedBox(height: 70, child: ElevatedButton(onPressed: () {}, style: ElevatedButton.styleFrom(backgroundColor: AppColors.primaryColor, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8))), child: const Text('Create ABHA\nusing Mobile', textAlign: TextAlign.center, style: TextStyle(color: Colors.white, fontSize: 13))))),
                      const SizedBox(width: 16),
                      Expanded(child: SizedBox(height: 70, child: ElevatedButton(onPressed: () {}, style: ElevatedButton.styleFrom(backgroundColor: AppColors.primaryColor, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8))), child: const Text('Create ABHA\nusing Aadhaar', textAlign: TextAlign.center, style: TextStyle(color: Colors.white, fontSize: 13))))),
                    ],
                  ),
                  const SizedBox(height: 40),

                  _buildCheckBox(value: _whatsappUpdates, text: "Get Updates on your WhatsApp", isWhatsapp: true, onChanged: (v) => setState(() => _whatsappUpdates = v!)),
                  _buildCheckBox(value: _termsAccepted, text: "I agree to Terms & Conditions", onChanged: (v) => setState(() => _termsAccepted = v!)),
                  _buildCheckBox(value: _linkAbhaAccepted, text: "Link my ABHA, health data from AarogyaOne to ABHA automatically...", onChanged: (v) => setState(() => _linkAbhaAccepted = v!)),
                  
                  const SizedBox(height: 30),
                  const Text('App v3.2.5 (1562)', style: TextStyle(color: AppColors.grey, fontSize: 12)),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildCheckBox({required bool value, required String text, required Function(bool?) onChanged, bool isWhatsapp = false}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(height: 24, width: 24, child: Checkbox(value: value, onChanged: onChanged, activeColor: AppColors.primaryColor)),
          const SizedBox(width: 12),
          Expanded(
            child: isWhatsapp
              ? Row(children: [
                  const Text("Get Updates on your ", style: TextStyle(fontSize: 13, color: AppColors.black)),
                  const Icon(Icons.call, color: Colors.green, size: 18),
                  const Text(" Whatsapp", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: AppColors.black)),
                ])
              : Text(text, style: const TextStyle(fontSize: 13, color: AppColors.grey, height: 1.4)),
          ),
        ],
      ),
    );
  }
}
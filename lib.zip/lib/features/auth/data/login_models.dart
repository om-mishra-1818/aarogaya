class LoginRequestModel {
  final String phoneNumber;
  final bool agreedToWhatsApp;
  // We keep these null for the first login step
  final String? otp;
  final String? transactionId;

  LoginRequestModel({
    required this.phoneNumber,
    this.agreedToWhatsApp = true,
    this.otp,
    this.transactionId,
  });

  Map<String, dynamic> toJson() {
    return {
      "phoneNumber": phoneNumber,
      "agreedToWhatsApp": agreedToWhatsApp,
      "otp": otp,
      "transactionId": transactionId,
    };
  }
}
class LoginResponseModel {
  final String? transactionId;
  final String? message;
  final bool hasProfile;

  LoginResponseModel({
    this.transactionId,
    this.message,
    required this.hasProfile,
  });

  factory LoginResponseModel.fromJson(Map<String, dynamic> json) {
    // 1. Check if the important data is wrapped inside a "result" key
    final data = json['result'] ?? json;

    return LoginResponseModel(
      // 2. Safely look for the ID (handling multiple possible names)
      transactionId: data['transactionId'] ?? data['txnId'] ?? data['authTransactionId'],
      message: data['message'],
      // 3. Check for the profile flag
      hasProfile: data['hasProfile'] ?? false,
    );
  }
}
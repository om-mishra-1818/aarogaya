import 'package:aarogyaone/features/auth/data/otp_respone.dart';
import 'package:dio/dio.dart';
import '../../../core/network/dio_client.dart';
import 'login_models.dart';

class AuthRepository {
  final Dio _dio = DioClient().dio;

  Future<LoginResponseModel> login(String phoneNumber, bool whatsappConsent) async {
    try {
      const String endpoint = "/abha-address-enrollment/auth-otp";
      
      final response = await _dio.post(
        endpoint,
        data: {
          "phoneNumber": phoneNumber,
          "agreedToWhatsApp": whatsappConsent,
        },
      );


      final model = LoginResponseModel.fromJson(response.data);
      
      
      // Only throw error if BOTH transactionId is missing AND hasProfile is false.
      if ((model.transactionId == null || model.transactionId!.isEmpty) && !model.hasProfile) {
        throw Exception("Server Error: No Transaction ID received.");
      }
      
      // If code reaches here, it means we are good to go!
      return model;

    } catch (e) {
      throw Exception(e.toString());
    }
  }

  // ... keep verifyOtp and resendOtp as they were ...
  Future<VerifyOtpResponse> verifyOtp({
    required String phoneNumber,
    required String transactionId, 
    required String otp
    }) async {
       try{
        const String endpoint = "/password-less-login/verify-otp";
        final response = await _dio.post(
          endpoint,
          data:{
            "phoneNumber": phoneNumber,
            "transactionId": transactionId,
            "otp": otp,
            "agreedToWhatsApp": null,
          },
        );
        return VerifyOtpResponse.fromJson(response.data);
       }catch(e){
        throw Exception(e.toString());
       }
  }

  Future<String> resendOtp(String phoneNumber) async {
       const String endpoint = "/abha-address-enrollment/auth-otp";
       final response = await _dio.post(endpoint, data: { "phoneNumber": phoneNumber, "agreedToWhatsApp": true });
       final model = LoginResponseModel.fromJson(response.data);
       // Allow null ID if profile exists here too
       if ((model.transactionId == null || model.transactionId!.isEmpty) && !model.hasProfile) {
          throw Exception("Failed to resend OTP.");
       }
       return model.transactionId ?? ""; 
  }
}
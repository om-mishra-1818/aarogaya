class VerifyOtpResponse{
  final String accessToken;
  final String refreshToken;
  final bool hasUserProfile;

  
VerifyOtpResponse({
  required this.accessToken,
  required this.refreshToken,
  required this.hasUserProfile,
});

factory VerifyOtpResponse.fromJson(Map<String, dynamic> json){
  return VerifyOtpResponse(
    accessToken: json['access_token'] ?? "",
    refreshToken: json['refresh_token'] ?? "",
    hasUserProfile: json['has_user_profile'] ?? false,
  );
}
}

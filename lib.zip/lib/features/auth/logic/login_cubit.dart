import 'package:aarogyaone/core/utils/preference_utils.dart';
import 'package:bloc/bloc.dart';
import '../data/auth_repository.dart';
import 'login_state.dart';

class LoginCubit extends Cubit<LoginState> {
  final AuthRepository _repository;

  LoginCubit(this._repository) : super(LoginInitial());

  void login({required String phoneNumber, required bool termsAccepted}) async {
    emit(LoginLoading());

    try {
      final response = await _repository.login(phoneNumber, termsAccepted);
      
      final safeTxnId = response.transactionId ?? ""; 

      emit(LoginSuccess(
        transactionId: safeTxnId, 
        phoneNumber: phoneNumber
      ));
      
    } catch (e) {
      final message = e.toString().replaceAll("Exception: ", "");
      emit(LoginError(message));
    }
  }

  void verifyOtp(String phoneNumber, String transactionId, String otp)async{
    emit(OtpLoading());
    try{
      final response  = await _repository.verifyOtp(
        phoneNumber: phoneNumber,
        transactionId: transactionId, 
        otp: otp
      );
      await PreferenceUtils().saveLoginDetails(response.accessToken);
      emit(OtpVerified());
    }catch(e){
      emit(OtpError(e.toString()));
    }
  }

  void resendOtp(String phoneNumber) async {    
    try {
      final newTxnId = await _repository.resendOtp(phoneNumber);
      emit(OtpResent(newTxnId));
    } catch (e) {
      final cleanError = e.toString().replaceAll("Exception: ", "");
      emit(OtpError(cleanError));
    }
  }
}
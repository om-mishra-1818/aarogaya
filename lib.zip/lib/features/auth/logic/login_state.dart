import 'package:flutter/foundation.dart';

@immutable
abstract class LoginState {}

class LoginInitial extends LoginState {}

class LoginLoading extends LoginState {}

class LoginSuccess extends LoginState {
  final String phoneNumber;
  final String transactionId;

  LoginSuccess({required this.phoneNumber, required this.transactionId});
}

class LoginError extends LoginState {
  final String message;

  LoginError(this.message);
}

class OtpLoading extends LoginState {}

class OtpVerified extends LoginState {
  OtpVerified();
}

class OtpError extends LoginState {
  final String message;
  OtpError(this.message);
}
class OtpResent extends LoginState {
  final String newTransactionId;
  OtpResent(this.newTransactionId);
}
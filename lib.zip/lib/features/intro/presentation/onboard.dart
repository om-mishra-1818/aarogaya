import 'package:aarogyaone/core/utils/preference_utils.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/utils/app_assets.dart';

class OnboardingContent {
  final String title;
  final String description;
  final String? image;
  final bool isFirstPage; 

  OnboardingContent({
    required this.title,
    required this.description,
    this.image,
    this.isFirstPage = false,
  });
}

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final PageController _pageController = PageController();
  int _currentPage = 0;

  final List<OnboardingContent> _pages = [
    OnboardingContent(
      title: "WHAT IS AAROGYAONE ?",
      description: "Aarogyaone is a digital health wallet that safeguards all your medical records.",
      isFirstPage: true, 
    ),
    OnboardingContent(
      title: "Create ABHA & Link Medical Records",
      description: "Get quick ABHA id/address and link all your medical records.",
      image: AppAssets.onboarding2, 
    ),
    OnboardingContent(
      title: "UPLOAD YOUR HEALTH RECORD",
      description: "Store all your health records digitally & get rid of paper files.",
      image: AppAssets.onboarding3,
    ),
    OnboardingContent(
      title: "CONSENT BASED SHARING",
      description: "We value your privacy; hence consent is always taken before sharing.",
      image: AppAssets.onboarding4,
    ),
    OnboardingContent(
      title: "ANYTIME ANYWHERE",
      description: "Your medical records are just a click away, get it anytime anywhere.",
      image: AppAssets.onboarding5,
    ),
  ];

  void _completeOnboarding() async {
    await PreferenceUtils().setOnboardingComplete();
    if (mounted) context.go('/login');
  }

  void _nextPage() {
    _pageController.nextPage(duration: const Duration(milliseconds: 300), curve: Curves.easeIn);
  }
  
  void _prevPage() {
    _pageController.previousPage(duration: const Duration(milliseconds: 300), curve: Curves.easeIn);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.white,
      body: Stack(
        children: [
          
          Positioned(
            top: 300, left: -60,
            child: Container(
              height: 160, width: 90,
              decoration: BoxDecoration(
                color: AppColors.secondaryColor1,
                borderRadius: const BorderRadius.only(topRight: Radius.circular(100), bottomRight: Radius.circular(100)),
              ),
            ),
          ),
          Positioned(
            top: -100, right: -100,
            child: Container(
              height: 220, width: 220,
              decoration: BoxDecoration(color: AppColors.primaryColor, shape: BoxShape.circle),
            ),
          ),

          SafeArea(
            child: Column(
              children: [
                const SizedBox(height: 30), 
                Image.asset(AppAssets.logo, height: 60),
                
                Expanded(
                  child: PageView.builder(
                    controller: _pageController,
                    itemCount: _pages.length,
                    onPageChanged: (index) => setState(() => _currentPage = index),
                    itemBuilder: (context, index) => _buildPageContent(_pages[index]),
                  ),
                ),

                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(
                    _pages.length,
                    (index) => AnimatedContainer(
                      duration: const Duration(milliseconds: 300),
                      margin: const EdgeInsets.symmetric(horizontal: 4),
                      height: 8,
                      width: _currentPage == index ? 30 : 8,
                      decoration: BoxDecoration(
                        color: _currentPage == index ? AppColors.secondaryColor2 : AppColors.lightGrey,
                        borderRadius: BorderRadius.circular(4),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 30),

                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      if (_currentPage == 0)
                        ElevatedButton(
                          onPressed: _completeOnboarding,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppColors.primaryColor,
                            padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 12),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                          ),
                          child: const Text("SKIP", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                        )
                      else
                        InkWell(
                          onTap: _prevPage,
                          borderRadius: BorderRadius.circular(50),
                          child: Container(
                            height: 50, width: 50,
                            decoration: BoxDecoration(color: AppColors.primaryColor, shape: BoxShape.circle),
                            child: const Icon(Icons.arrow_back_ios_new, color: Colors.white, size: 20),
                          ),
                        ),

                      InkWell(
                        onTap: (_currentPage == _pages.length - 1) ? _completeOnboarding : _nextPage,
                        borderRadius: BorderRadius.circular(50),
                        child: Container(
                          height: 50, width: 50,
                          decoration: BoxDecoration(color: AppColors.secondaryColor1, shape: BoxShape.circle),
                          child: Icon((_currentPage == _pages.length - 1) ? Icons.check : Icons.arrow_forward_ios, color: Colors.white, size: 20),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPageContent(OnboardingContent item) {
    return Column(
      children: [
        const Spacer(flex: 1),
        if (item.isFirstPage) ...[
          const Text("APPROVED BY", style: TextStyle(color: AppColors.grey, fontWeight: FontWeight.bold, letterSpacing: 1.2, fontSize: 12)),
          const SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset(AppAssets.abdmLogo, height: 50, errorBuilder: (c,o,s)=> const Icon(Icons.shield)), 
              const SizedBox(width: 30),
              Image.asset(AppAssets.nhaLogo, height: 50, errorBuilder: (c,o,s)=> const Icon(Icons.local_hospital)),
            ],
          ),
        ] else ...[
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Image.asset(item.image!, height: 250, fit: BoxFit.contain),
          ),
        ],
        const Spacer(flex: 2),
        Container(
          width: double.infinity,
          margin: const EdgeInsets.symmetric(horizontal: 24),
          padding: const EdgeInsets.symmetric(vertical: 32, horizontal: 24),
          decoration: BoxDecoration(
            color: AppColors.secondaryColor2,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [BoxShadow(color: AppColors.secondaryColor2.withValues(alpha: 0.3), blurRadius: 15, offset: const Offset(0, 8))],
          ),
          child: Column(
            children: [
              Text(item.title, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              Text(item.description, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 14, height: 1.5)),
            ],
          ),
        ),
        const SizedBox(height: 40),
      ],
    );
  }
}
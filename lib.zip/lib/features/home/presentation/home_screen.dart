import 'package:aarogyaone/features/home/presentation/widgets/app_drawer.dart';
import 'package:flutter/material.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/utils/app_assets.dart';
import 'widgets/home_widgets.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  int _selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey, 
      backgroundColor: AppColors.scaffoldBackgroundColorTheme1,
      drawer: const AppDrawer(),

      appBar: AppBar(
        backgroundColor: AppColors.white,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: Icon(Icons.menu, color: AppColors.primaryColor),
          onPressed: () {
            _scaffoldKey.currentState?.openDrawer();
          },
        ),
        title: Image.asset(
          AppAssets.logo, 
          height: 35,
          fit: BoxFit.contain,
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.notifications_none, color: AppColors.primaryColor),
            onPressed: () {},
          ),
        ],
      ),

      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            HomeSectionHeader(
              title: "Family Members",
              action: "Switch Profile",
              showAddIcon: true,
              onActionTap: () {},
            ),
            const SizedBox(height: 10),
            const HomeProfileCard(),
            const SizedBox(height: 20),

            Row(
              children: [
                Expanded(
                  child: HomeActionCard(
                    title: "Health Locker",
                    subtitle: "View My Records",
                    btnText: "My Records",
                    imagePath: AppAssets.healthLocker, 
                    btnColor: AppColors.primaryColor,
                    onTap: () {},
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: HomeActionCard(
                    title: "ABHA",
                    subtitle: "Check Your ABHA",
                    btnText: "My ABHA",
                    imagePath: AppAssets.abha,
                    btnColor: AppColors.secondaryColor1,
                    onTap: () {},
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),

            HomeSectionHeader(
              title: "Book an Appointment",
              action: "History",
              showHistoryIcon: true,
              onActionTap: () {},
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton.icon(
                onPressed: () {},
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primaryColor,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                  elevation: 2,
                ),
                icon: const Icon(Icons.qr_code_scanner, color: Colors.white),
                label: const Text("Scan QR & Get Token", style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
              ),
            ),
            const SizedBox(height: 24),

           
            const SizedBox(height: 24),

            Row(
              children: [
                Expanded(
                  child: HomeActionCard(
                    title: "My Health",
                    subtitle: "Manage Health Data",
                    btnText: "My Health",
                    imagePath: AppAssets.myHealth,
                    btnColor: AppColors.secondaryColor1,
                    onTap: () {},
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: HomeActionCard(
                    title: "Blood Bank",
                    subtitle: "Blood Availability",
                    btnText: "Blood Bank",
                    imagePath: AppAssets.bloodBank,
                    btnColor: AppColors.primaryColor,
                    // Replaced withOpacity for compatibility
                    iconBgColor: AppColors.errorColor.withValues(alpha: 0.1), 
                    onTap: () {},
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),

            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: AppColors.white,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: AppColors.lightGrey),
              ),
              child: Row(
                children: [
                  Image.asset(AppAssets.pmjayLogo, height: 24, width: 24, errorBuilder: (c,o,s) => const Icon(Icons.shield, color: Colors.orange)),
                  const SizedBox(width: 12),
                  const Text("PMJAY", style: TextStyle(fontWeight: FontWeight.bold)),
                ],
              ),
            ),
            const SizedBox(height: 24),

            const Text("AarogayaOne Doctors", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: HomeServiceItem(
                    imagePath: AppAssets.doctorSearch, 
                    label: "Doctors", 
                    onTap: () {},
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: HomeServiceItem(
                    imagePath: AppAssets.appointmentHistory, 
                    label: "Appointment\nHistory", 
                    onTap: () {},
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: HomeServiceItem(
                    imagePath: AppAssets.hospital, 
                    label: "Hospital", 
                    onTap: () {},
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),

            HomeSectionHeader(title: "VBlogs", action: "View All", onActionTap: () {}),
            const SizedBox(height: 10),
            Container(
              height: 160,
              decoration: BoxDecoration(
                color: Colors.black87,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Center(
                child: Icon(Icons.play_circle_fill, size: 50, color: AppColors.white),
              ),
            ),
            const SizedBox(height: 40),
          ],
        ),
      ),

      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: (index) => setState(() => _selectedIndex = index),
        type: BottomNavigationBarType.fixed,
        backgroundColor: AppColors.white,
        selectedItemColor: AppColors.primaryColor,
        unselectedItemColor: AppColors.grey,
        selectedLabelStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
        unselectedLabelStyle: const TextStyle(fontSize: 12),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
          BottomNavigationBarItem(icon: Icon(Icons.favorite_outline), label: "My Health"),
          BottomNavigationBarItem(icon: Icon(Icons.folder_open), label: "Records"),
          BottomNavigationBarItem(icon: Icon(Icons.shield_outlined), label: "ABHA"),
          BottomNavigationBarItem(icon: Icon(Icons.person_outline), label: "Profile"),
        ],
      ),
    );
  }
}
import 'package:flutter/material.dart';
import '../../../../core/theme/app_colors.dart';

class HomeSectionHeader extends StatelessWidget {
  final String title;
  final String? action;
  final VoidCallback? onActionTap;
  final bool showAddIcon;
  final bool showHistoryIcon;

  const HomeSectionHeader({
    super.key,
    required this.title,
    this.action,
    this.onActionTap,
    this.showAddIcon = false,
    this.showHistoryIcon = false,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(
          children: [
            Text(
              title,
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: AppColors.lightBlack),
            ),
            if (showAddIcon) ...[
              const SizedBox(width: 8),
              Icon(Icons.add_circle, color: AppColors.primaryColor, size: 20),
            ]
          ],
        ),
        if (action != null)
          InkWell(
            onTap: onActionTap,
            child: Row(
              children: [
                if (showHistoryIcon) ...[
                  Icon(Icons.history, size: 16, color: AppColors.secondaryColor1),
                  const SizedBox(width: 4),
                ],
                Text(
                  action!,
                  style: TextStyle(color: AppColors.secondaryColor1, fontWeight: FontWeight.bold, fontSize: 14),
                ),
              ],
            ),
          )
      ],
    );
  }
}

// --- 2. ACTION CARD (Updated: Removed withOpacity) ---
class HomeActionCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final String btnText;
  final String imagePath;
  final Color btnColor;
  final Color? iconBgColor;
  final VoidCallback? onTap;

  const HomeActionCard({
    super.key,
    required this.title,
    required this.subtitle,
    required this.btnText,
    required this.imagePath,
    required this.btnColor,
    this.iconBgColor,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.lightGrey),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05), 
            blurRadius: 4, 
            offset: const Offset(0, 2)
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              // Image Container
              Container(
                height: 40, width: 40,
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  // UPDATED: Used withValues(alpha: 0.3)
                  color: iconBgColor ?? AppColors.lightGrey.withValues(alpha: 0.3),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Image.asset(imagePath, fit: BoxFit.contain),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  title,
                  style: TextStyle(color: btnColor, fontWeight: FontWeight.bold, fontSize: 14),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            subtitle,
            style: const TextStyle(fontSize: 12, color: AppColors.textColor),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity, height: 32,
            child: ElevatedButton(
              onPressed: onTap ?? () {},
              style: ElevatedButton.styleFrom(
                backgroundColor: btnColor,
                padding: EdgeInsets.zero,
                elevation: 0,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
              ),
              child: Text(btnText, style: const TextStyle(color: Colors.white, fontSize: 12)),
            ),
          ),
        ],
      ),
    );
  }
}

class HomeServiceItem extends StatelessWidget {
  final String imagePath;
  final String label;
  final VoidCallback? onTap;

  const HomeServiceItem({
    super.key,
    required this.imagePath,
    required this.label,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        
      
        alignment: Alignment.center,
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 4),
        
        decoration: BoxDecoration(
          color: AppColors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColors.lightGrey),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.05), 
              blurRadius: 4, 
              offset: const Offset(0, 2)
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset(imagePath, height: 32, width: 32),
            const SizedBox(height: 8),
            Text(
              label,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: AppColors.lightBlack),
            ),
          ],
        ),
      ),
    );
  }
}

class HomeProfileCard extends StatelessWidget {
  const HomeProfileCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.primaryColor, width: 1),
      ),
      child: Row(
        children: [
          Container(
            height: 50, width: 50,
            decoration: BoxDecoration(
              color: Colors.brown.shade100,
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Icon(Icons.person, color: Colors.brown),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("Mishra Om Suryanarayan", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                const SizedBox(height: 2),
                const Text("91645412222152@sbx", style: TextStyle(fontSize: 12, color: AppColors.grey)),
                const SizedBox(height: 4),
                Row(
                  children: [
                    const Text("KYC Verified", style: TextStyle(fontSize: 11, color: AppColors.lightGreen, fontWeight: FontWeight.bold)),
                    const SizedBox(width: 4),
                    const Icon(Icons.verified, color: AppColors.lightGreen, size: 14),
                  ],
                ),
              ],
            ),
          ),
          Column(
            children: [
              Icon(Icons.check_circle, color: AppColors.primaryColor, size: 22),
              const SizedBox(height: 8),
              Icon(Icons.edit_square, color: AppColors.secondaryColor1, size: 20),
            ],
          )
        ],
      ),
    );
  }
}
import 'package:aarogyaone/core/theme/app_colors.dart';
import 'package:aarogyaone/core/utils/app_assets.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';


class AppDrawer extends StatelessWidget {
  const AppDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    return Drawer(
      backgroundColor: AppColors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.zero, 
      ),
      child: Column(
        children: [
          
          _buildHeader(),

          //  MENU ITEMS
          Expanded(
            child: ListView(
              padding: EdgeInsets.zero,
              children: [
                _buildDrawerItem(AppAssets.icProfile, "My Profile", () {}),
                _buildDrawerItem(AppAssets.icFamily, "My Family Members", () {}),
                _buildDivider(),
                
                _buildDrawerItem(AppAssets.icLanguage, "Languages / Theme", () {}),
                _buildDivider(),
                
                _buildDrawerItem(AppAssets.icHistory, "ABHA Token History", () {}),
                _buildDrawerItem(AppAssets.icResetPassword, "Reset ABHA Password", () {}),
                _buildDivider(),
                
                _buildDrawerItem(AppAssets.icScan, "Scan And Pay", () {}),
                _buildDrawerItem(AppAssets.icPaymentHistory, "Payment Transaction History", () {}),
                _buildDivider(),
                
                _buildDrawerItem(AppAssets.icChat, "Chat With Us", () {}),
                _buildDrawerItem(AppAssets.icNotification, "Notifications", () {}),
                _buildDivider(),
                
                _buildDrawerItem(AppAssets.icPrivacy, "Privacy Policy", () {}),
                _buildDrawerItem(AppAssets.icTerms, "Terms & Conditions", () {}),
                _buildDivider(),
                
                _buildDrawerItem(AppAssets.icLogout, "Logout", () {
                  context.go('/login');
                }),
              ],
            ),
          ),

          
          _buildFooter(),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 60, 16, 20),
      decoration: const BoxDecoration(
        border: Border(bottom: BorderSide(color: AppColors.lightGrey, width: 1)),
      ),
      child: Row(
        children: [
          Container(
            width: 50, height: 50,
            decoration: BoxDecoration(
              color: Colors.grey.shade200,
              borderRadius: BorderRadius.circular(8),
              image: const DecorationImage(
                 // Uses Asset Image for offline support
                 image: AssetImage(AppAssets.icProfile), 
                 fit: BoxFit.cover,
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  "Mishra Om", 
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                  maxLines: 1, overflow: TextOverflow.ellipsis,
                ),
                const Text(
                  "Suryanarayan",
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                  maxLines: 1, overflow: TextOverflow.ellipsis,
                ),
                Text(
                  "91645412222152@sbx", 
                  style: const TextStyle(fontSize: 12, color: AppColors.grey),
                  maxLines: 1, overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDrawerItem(String iconPath, String title, VoidCallback onTap) {
    return ListTile(
      horizontalTitleGap: 12, 
      minLeadingWidth: 24,
      contentPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 0),
      
      leading: Image.asset(
        iconPath, 
        width: 24, height: 24,
        color: AppColors.primaryColor, 
      ),
      title: Text(
        title,
        style:  TextStyle(fontSize: 14, fontWeight: FontWeight.w500, color: AppColors.black),
      ),
      onTap: onTap,
      dense: true,
    );
  }

  Widget _buildDivider() {
    return Divider(
      height: 1, 
      thickness: 1, 
      color: AppColors.primaryColor.withValues(alpha: 0.2), 
      indent: 16,      
      endIndent: 16,   
    );
  }

  Widget _buildFooter() {
    return Container(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Safer Logo loading
              Image.asset(
                AppAssets.logo, 
                height: 20, 
                errorBuilder: (c, o, s) => const Icon(Icons.broken_image, size: 20),
              ),
              const SizedBox(width: 8),
              const Text("v3.2.5 (1562)", style: TextStyle(color: AppColors.grey, fontSize: 12)),
            ],
          ),
          const SizedBox(height: 8),
          const Text("Approved By", style: TextStyle(color: AppColors.grey, fontSize: 10)),
          const SizedBox(height: 8),
          
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            mainAxisSize: MainAxisSize.min, 
            children: [
               Flexible(
                 child: Image.asset(
                   AppAssets.abdmLogo, 
                   height: 30, 
                   fit: BoxFit.contain,
                   // Prevents crash if image is missing
                   errorBuilder: (c, o, s) => const Text("ABDM", style: TextStyle(fontSize: 10, color: Colors.grey)),
                 ),
               ),
               const SizedBox(width: 16),
               Flexible(
                 child: Image.asset(
                   AppAssets.nhaLogo, 
                   height: 30, 
                   fit: BoxFit.contain,
                   // Prevents crash if image is missing
                   errorBuilder: (c, o, s) => const Text("NHA", style: TextStyle(fontSize: 10, color: Colors.grey)),
                 ),
               ),
            ],
          ),
          const SizedBox(height: 10),
        ],
      ),
    );
  }
}
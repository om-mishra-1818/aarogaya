class AppAssets {
  static const String onboarding1 = "assets/images/aarogaya_with_aprroved_by.jpg";
  static const String onboarding2 = "assets/images/abha_on_bording_id.png";
  static const String onboarding3 = "assets/images/first_intro.png";
  static const String onboarding4 = "assets/images/second_intro.png";
  static const String onboarding5 = "assets/images/third_intro.png";
  static const String abdmLogo = "assets/images/ABDM.PNG";
  static const String nhaLogo = "assets/images/Nha_pg_logo.png";

  static const String logo = "assets/images/app_logo.png";
  static const String flag = "assets/images/img_india_flag.png";

//HomeScreen
  static const String healthLocker = "assets/icons/ic_document.png";
  static const String abha = "assets/icons/ic_abha_linked.jpg";
  static const String myHealth = "assets/icons/ic_health_locker.png";
  static const String bloodBank = "assets/vital_icons/blood-type.png";
  static const String pmjayLogo = "assets/icons/ic_pmjay.png";
  static const String doctorSearch = "assets/icons/doctor.png";
  static const String appointmentHistory = "assets/icons/appointment_history.png";
  static const String hospital = "assets/icons/ic_hospital.png";

  //Drawer Icons
  static const String icProfile = "assets/icons/ic_drawer_my_profile.png";
  static const String icFamily = "assets/icons/ic_drawer_add_member.png";
  static const String icLanguage = "assets/icons/ic_language.png";
  static const String icHistory = "assets/icons/ic_drawer_history.png";
  static const String icResetPassword = "assets/icons/ic_reset_pwd.png";
  static const String icScan = "assets/icons/ic_scan_and_pay.png";
  static const String icPaymentHistory = "assets/icons/ic_transition_history.png";
  static const String icChat = "assets/icons/ic_whatsapp_icon.png";
  static const String icNotification = "assets/icons/ic_drawer_notification.png";
  static const String icPrivacy = "assets/icons/ic_privacy_policy.png";
  static const String icTerms = "assets/icons/ic_drawer_terms.png";
  static const String icLogout = "assets/icons/ic_drawer_privacy_policy.png";
  
  

}
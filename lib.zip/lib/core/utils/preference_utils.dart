import 'package:shared_preferences/shared_preferences.dart';

class PreferenceUtils {
  static final PreferenceUtils _instance = PreferenceUtils._internal();
  factory PreferenceUtils() => _instance;
  PreferenceUtils._internal();

  late final SharedPreferences _prefs;

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
  }

  static const String keyOnboardingComplete = 'onboarding_complete';
  static const String keyIsLoggedIn = 'is_logged_in';
  static const String keyUserToken = 'user_token';

  bool get isOnboardingComplete => _prefs.getBool(keyOnboardingComplete) ?? false;
  
  bool get isLoggedIn => _prefs.getBool(keyIsLoggedIn) ?? false;
  
  String? get userToken => _prefs.getString(keyUserToken);

  Future<void> setOnboardingComplete() async {
    await _prefs.setBool(keyOnboardingComplete, true);
  }

  Future<void> saveLoginDetails(String token) async {
    await _prefs.setBool(keyIsLoggedIn, true);
    await _prefs.setString(keyUserToken, token);
  }

  Future<void> clearAll() async {
    await _prefs.clear();
  }
}
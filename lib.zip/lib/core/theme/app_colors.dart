import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AppColors {
  static bool isDark = false;
  static Color primaryColor = const Color(0xFF448740); // Default Green
  static Color secondaryColor1 = const Color(0xFFFF9933); // Orange
  static Color secondaryColor2 = const Color(0xFF346E9C); // Blue

  static Future<void> init() async {
    final pref = await SharedPreferences.getInstance();
    
    int? savedPrimaryColor = pref.getInt(Constants.primaryColor);
    int? secondaryColor = pref.getInt(Constants.secondaryColor);
    int? secondaryColor2pref = pref.getInt(Constants.secondaryColor2);

    if (savedPrimaryColor != null && secondaryColor != null && secondaryColor2pref != null) {
      primaryColor = Color(savedPrimaryColor);
      secondaryColor1 = Color(secondaryColor);
      secondaryColor2 = Color(secondaryColor2pref);
    }
  }

  // --- Theme Colors ---
  static const Color white = Color(0xFFFDFEFE);
  static const Color black = Colors.black;
  static const Color lightBlack = Color(0xFF2D2D2D);

  static const Color errorColor = Color(0xFFEA4335);

  // --- Common Colors ---
  static Color darkHighlight = Colors.red[700]!;
  static const Color grey = Color(0xFFA8A8A8);
  static const Color lightGrey = Color(0xFFEFEFEF);
  static const Color lightBlue = Color(0xFF346E9C);
  static const Color lightGreen = Color(0xFF00a76f);
  static const Color orangeIntro = Color(0xFFEC6B15);
  static const Color lightGreyBlack = Color(0xFFA8A8A8);

  // --- Light Theme ---
  static const Color scaffoldBackgroundColorTheme1 = Colors.white;
  static const Color appBarColor = Color(0xFFdee2e6);
  static Color cardColorLight = primaryColor;
  static Color iconColor = primaryColor;
  static const Color textColor = Color(0xFF2D2D2D);
  static const Color surfaceColorLight = grey;

  // --- Theme 2 ---
  static Color drawerHeaderBottomLine = const Color.fromRGBO(68, 135, 64, 0.5);
}

// ⚠️ Add this simple class here or in core/utils/constants.dart to fix errors
class Constants {
  static const String primaryColor = 'primary_color_key';
  static const String secondaryColor = 'secondary_color_key';
  static const String secondaryColor2 = 'secondary_color_2_key';
}
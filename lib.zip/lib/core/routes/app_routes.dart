import 'package:aarogyaone/features/auth/presentation/login_using_abha_screen.dart';
import 'package:aarogyaone/features/home/presentation/home_screen.dart';
import 'package:aarogyaone/features/intro/presentation/onboard.dart';
import 'package:go_router/go_router.dart';
import '../../features/auth/presentation/login_screen.dart';
import '../../features/intro/presentation/splash_screen.dart';

final GoRouter appRouter = GoRouter(
  initialLocation: '/',
  routes: [
    GoRoute(
      path: '/',
      builder: (context, state) => const SplashScreen(),
    ),
    GoRoute(
      path: '/onboarding',
      builder: (context, state) => const OnboardingScreen(),
    ),
    GoRoute(
      path: '/login',
      builder: (context, state) => const LoginScreen(),
    ),
    GoRoute(path: '/home',
    builder: (context, state)=> const HomeScreen()
    ),
    GoRoute(path: '/login-abha',
    builder: (context,state)=> const LoginUsingAbhaScreen()
    )
  ]
);
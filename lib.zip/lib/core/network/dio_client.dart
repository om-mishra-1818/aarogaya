import 'package:dio/dio.dart';
import 'package:pretty_dio_logger/pretty_dio_logger.dart';

class DioClient {
  static final DioClient _instance = DioClient._internal();
  factory DioClient() => _instance;
  
  late final Dio _dio;

  // Private Constructor
  DioClient._internal() {
    _dio = Dio(
      BaseOptions(
        baseUrl: "https://dev-api.aarogya.one/api/v1",
        // connectTimeout: const Duration(seconds: 10),
        // receiveTimeout: const Duration(seconds: 10),
        headers: {
          "Content-Type": "application/json",
          "x-tenant-id": "prod", 
        },
      ),
    );

    _dio.interceptors.add(
      PrettyDioLogger(
        requestHeader: true,
        requestBody: true,
        responseBody: true,
        compact: true,
        maxWidth: 90,
      ),
    );
  }

  // Expose the configured Dio instance
  Dio get dio => _dio;
}